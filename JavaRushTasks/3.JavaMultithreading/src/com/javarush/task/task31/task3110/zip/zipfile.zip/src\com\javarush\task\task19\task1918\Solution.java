package com.javarush.task.task19.task1918;

/* 
Знакомство с тегами
*/

import java.io.*;
import java.util.ArrayList;

public class Solution {
    public static void main(String[] args) throws IOException{
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String file = reader.readLine();
        reader.close();
        BufferedReader fr = new BufferedReader(new FileReader(file));
        StringBuilder sb = new StringBuilder();
        String s;
        while ((s=fr.readLine())!=null) {
            sb.append(s);
        }
        fr.close();

        sb.delete(0,sb.indexOf("<")+1);   // обрезаем строку до начала тегов
        String buffer = sb.toString();
        String[] array = buffer.split("<");
        String[] tags = new String[array.length];
        Stack stack = new Stack();
        // выделяем все теги
        for (int i=0;i<array.length;i++) {
            int i1 = array[i].indexOf(">");
            int i2 = array[i].indexOf(" ");
            if (i2 == -1) tags[i] = array[i].substring(0, array[i].indexOf(">"));
            else {
                if (i1 < i2) { tags[i] = array[i].substring(0, array[i].indexOf(">")); }
                else { tags[i] = array[i].substring(0, array[i].indexOf(" ")); }
            }
        }

        int tagstart = 0, tagfinish = 0;
        for (int i=0;i<tags.length;i++) {
            if (stack.getSize() == 0 && tags[i].startsWith("/")) {} // если тег закрывающийся - пропускаем
            else {
                if (tags[i] == args[0]) tagstart = i;   // если тег - нужный, отмечаем где начинается строка
                if (stack.getSize() == 0) {             // кладем в стек, если он пуст
                    stack.pop(tags[i]);
                }
                else if (tags[i].equals("/"+stack.get())) {stack.push(); tagfinish = i;}       // если не пуст - проверяем на закрывающий тег
                else stack.pop(tags[i]);                                                        // не закрывающий - кладем еще 1 элемент в стек
                if (stack.getSize() == 0 && tags[tagstart].equals(args[0])) {                   // если стек обнулился и тег - нужный, то печатаем строку
                    for (int ii = tagstart; ii<tagfinish+1; ii++){
                        if (ii == tagfinish) System.out.print("<"+array[ii].split(">")[0]+">");
                        else System.out.print("<"+array[ii]);
                    }
                    System.out.println();
                }
                if (stack.getSize() == 0){                                  // после обнуления стека начинаем со следующего элемента,
                    i=tagstart;                                             // чтобы не пропустить вложенные теги
                    tagstart = i+1;
                }
            }
        }
    }

    private static class Stack {
        ArrayList<String> list;
        int index;

        Stack(){
            this.list = new ArrayList<String>();
            this.index = 0;
        }
        private void pop(String s){
            list.add(s);
            index++;
        }
        private String push(){
            String s = null;
            if (index<1) try {throw new IndexOutOfBoundsException();}catch (Exception ignored) {}
            else{
                s = list.get(index-1);
                list.remove(index-1);
                index--;
            }
            return s;
        }
        private String get(){
            String s = null;
            if (index<1) try {throw new IndexOutOfBoundsException();}catch (Exception ignored) {}
            else{
                s = list.get(index-1);
            }
            return s;
        }
        private int getSize(){
            return index;
        }
    }
}
