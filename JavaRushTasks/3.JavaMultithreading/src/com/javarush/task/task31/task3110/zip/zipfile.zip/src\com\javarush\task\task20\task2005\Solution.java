package com.javarush.task.task20.task2005;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* 
Очень странные дела
*/

public class Solution {
    public static void main(String[] args) {
        //исправь outputStream/inputStream в соответствии с путем к твоему реальному файлу
        try {
            File your_file_name = new File("3");
            OutputStream outputStream = new FileOutputStream(your_file_name);
            InputStream inputStream = new FileInputStream(your_file_name);

            Human ivanov = new Human("Ivanov", new Asset("home"), new Asset("car"));
            Human sidorov = new Human("Sidorov", new Asset("home"), new Asset("car"));
            ivanov.save(outputStream);
            outputStream.flush();

            Human somePerson = new Human();
            somePerson.load(inputStream);
            //check here that ivanov equals to somePerson - проверьте тут, что ivanov и somePerson равны
            System.out.print(ivanov.name+" ");
            for (int i=0;i<ivanov.assets.size();i++){
                System.out.print(ivanov.assets.get(i).getName()+" ");
                System.out.print(String.valueOf(ivanov.assets.get(i).getPrice())+" ");
            }
            System.out.println();
            System.out.print(somePerson.name+" ");
            for (int i=0;i<somePerson.assets.size();i++){
                System.out.print(somePerson.assets.get(i).getName()+" ");
                System.out.print(String.valueOf(somePerson.assets.get(i).getPrice())+" ");
            }
            System.out.println();
            System.out.println(ivanov.equals(ivanov));
            System.out.println(ivanov.equals(somePerson));
            System.out.println(ivanov.equals(sidorov));
            inputStream.close();

        } catch (IOException e) {
            //e.printStackTrace();
            System.out.println("Oops, something wrong with my file");
        } catch (Exception e) {
            //e.printStackTrace();
            System.out.println("Oops, something wrong with save/load method");
        }
    }

    public static class Human {
        public String name;
        public List<Asset> assets = new ArrayList<>();

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            Human human = (Human) o;

            if (!name.equals(human.name)) return false;
            return assets != null ? assets.equals(human.assets) : human.assets == null;

        }

        @Override
        public int hashCode() {
            int result = name != null ? name.hashCode() : 0;
            result = 31 * result + (assets != null ? assets.hashCode() : 0);
            return result;
        }

        public Human() {
        }

        public Human(String name, Asset... assets) {
            this.name = name;
            if (assets != null) {
                this.assets.addAll(Arrays.asList(assets));
            }
        }

        public void save(OutputStream outputStream) throws Exception {
            //implement this method - реализуйте этот метод
            PrintWriter writer = new PrintWriter(outputStream);
            writer.println(name);
            writer.print(assets.size());
            for (int i=0;i<assets.size();i++){
                writer.print(System.lineSeparator());
                writer.println(assets.get(i).getName());
                writer.print(String.valueOf(assets.get(i).getPrice()));
            }
            writer.close();
        }

        public void load(InputStream inputStream) throws Exception {
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            name = reader.readLine();
            int size = Integer.parseInt(reader.readLine());
            for (int i=0;i<size;i++){
                Asset asset = new Asset(reader.readLine());
                asset.setPrice(Double.parseDouble(reader.readLine()));
                assets.add(asset);
            }
            reader.close();
        }
    }
}
