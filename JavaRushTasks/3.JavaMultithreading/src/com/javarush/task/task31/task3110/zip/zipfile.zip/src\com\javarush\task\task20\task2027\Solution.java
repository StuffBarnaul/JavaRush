package com.javarush.task.task20.task2027;

import java.util.ArrayList;
import java.util.List;

/*
Кроссворд
*/
public class Solution {
    public static void main(String[] args) {
        int[][] crossword = new int[][]{
                {'f', 'd', 'e', 'r', 'l', 'k'},
                {'u', 's', 'a', 'm', 'e', 'o'},
                {'l', 'n', 'g', 'r', 'o', 'v'},
                {'m', 'l', 'p', 'r', 'r', 'h'},
                {'p', 'o', 'e', 'e', 'j', 'j'}
        };
        List<Word> words = (detectAllWords(crossword, "home", "same"));
//        int[][] crossword = new int[][]{
//                {'f', 'e', 'e', 'e', 'l', 'e'},
//                {'u', 's', 'n', 'n', 'n', 'd'},
//                {'l', 'e', 'n', 'o', 'n', 'e'},
//                {'m', 'm', 'n', 'n', 'n', 'h'},
//                {'p', 'e', 'e', 'e', 'j', 'e'},
//        };
//        List<Word> words = (detectAllWords(crossword, "one","dehe","fulmp","peeeje","ehede","edehe"));
        for (Word word:words) {
            System.out.println(word);
        }
        /*
Ожидаемый результат
home - (5, 3) - (2, 0)
same - (1, 1) - (4, 1)
         */
    }

    public static List<Word> detectAllWords(int[][] crossword, String... words) {
        List<Word> list = new ArrayList<Word>();
        int width = crossword[0].length;
        int heigth = crossword.length;
        for (int k=0;k<words.length;k++) {
            Word currentWord = new Word(words[k]);
            boolean b = false;
            char[] cwca = words[k].toCharArray();
            int len = cwca.length-1;
            for (int i = 0; i < heigth; i++) {
                for (int j = 0; j < width; j++) {
                    if (crossword[i][j] == cwca[0]){
                        Word word = new Word("");
                        word = isHere(crossword,i,j,-1,-1,cwca); if (word!=null) list.add(word);
                        word = isHere(crossword,i,j,-1,0,cwca); if (word!=null) list.add(word);
                        word = isHere(crossword,i,j,-1,1,cwca); if (word!=null) list.add(word);
                        word = isHere(crossword,i,j,0,-1,cwca); if (word!=null) list.add(word);
                        word = isHere(crossword,i,j,0,1,cwca); if (word!=null) list.add(word);
                        word = isHere(crossword,i,j,1,-1,cwca); if (word!=null) list.add(word);
                        word = isHere(crossword,i,j,1,0,cwca); if (word!=null) list.add(word);
                        word = isHere(crossword,i,j,1,1,cwca); if (word!=null) list.add(word);
                    }
                }
            }
        }
        return list;
    }

    public static Word isHere (int[][] crossword,int si, int sj, int di,int dj,char[] cwca){
        boolean result = false;
        int width = crossword[0].length;
        int heigth = crossword.length;
        int ti=si;
        int tj=sj;
        for (int i=1;i<cwca.length;i++){
            if (si+di>=0 && si+di<heigth && sj+dj>=0 && sj+dj<width){
                if (cwca[i] == (char)crossword[si+di][sj+dj]){
                    if (i == cwca.length-1) {
                        result = true;
                    }
                } else break;
            }
            si+=di;sj+=dj;
        }
        if (result){
            Word word = new Word(new String(cwca));
            word.setStartPoint(tj,ti);
            word.setEndPoint(sj,si);
            return word;
        }
        return null;
    }

    public static class Word {
        private String text;
        private int startX;
        private int startY;
        private int endX;
        private int endY;

        public Word(String text) {
            this.text = text;
        }

        public void setStartPoint(int i, int j) {
            startX = i;
            startY = j;
        }

        public void setEndPoint(int i, int j) {
            endX = i;
            endY = j;
        }

        @Override
        public String toString() {
            return String.format("%s - (%d, %d) - (%d, %d)", text, startX, startY, endX, endY, System.lineSeparator());
        }
    }
}
