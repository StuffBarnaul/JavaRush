package com.javarush.task.task19.task1916;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
/* 
Отслеживаем изменения
*/

public class Solution {
    public static List<LineItem> lines = new ArrayList<LineItem>();

    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        String file1 = reader.readLine();
        String file2 = reader.readLine();
        reader.close();
        BufferedReader fr1 = new BufferedReader(new FileReader(file1));
        BufferedReader fr2 = new BufferedReader(new FileReader(file2));
        boolean b1=true,b2=true;
        String s11 = fr1.readLine();
        String s21 = fr2.readLine();
        String s12="",s22="";
        while (b1|b2){
            if (b1) s12 = fr1.readLine();
            if (b2) s22 = fr2.readLine();
            b1=true;
            b2=true;
            if (s12 == null) b1 = false;
            if (s22 == null) b2 = false;
            LineItem line = null;
            if ((s12 == null)&&(s22 == null)){
                if (s11 == null) line = new LineItem(Type.ADDED,s21); else
                if (s21 == null) line = new LineItem(Type.REMOVED,s11); else
                if (s11.equals(s21)) line = new LineItem(Type.SAME,s11);
            }else
            if (s11.equals(s21)) {line = new LineItem(Type.SAME,s11);s21=s22;s11=s12;} else
            if (s11.equals(s22)) {line = new LineItem(Type.ADDED,s21); b1 = false; s21 = s22;} else
            if (s12.equals(s21)) {line = new LineItem(Type.REMOVED,s11);b2 = false; s11 = s12;}
            lines.add(line);

        }
        fr1.close();
        fr2.close();
    }


    public static enum Type {
        ADDED,        //добавлена новая строка
        REMOVED,      //удалена строка
        SAME          //без изменений
    }

    public static class LineItem {
        public Type type;
        public String line;

        public LineItem(Type type, String line) {
            this.type = type;
            this.line = line;
        }
    }
}