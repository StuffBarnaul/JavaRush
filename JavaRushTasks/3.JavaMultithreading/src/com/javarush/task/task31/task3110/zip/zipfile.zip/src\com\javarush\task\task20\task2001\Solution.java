package com.javarush.task.task20.task2001;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/* 
Читаем и пишем в файл: Human
*/
public class Solution {
    public static void main(String[] args) {
        //исправьте outputStream/inputStream в соответствии с путем к вашему реальному файлу
        try {
            File your_file_name = new File("3");
            OutputStream outputStream = new FileOutputStream(your_file_name);
            InputStream inputStream = new FileInputStream(your_file_name);

            Human ivanov1 = new Human("Ivanov1");
            //Human ivanov2 = new Human("Ivanov2");
            ivanov1.save(outputStream);
            //ivanov2.save(outputStream);
            outputStream.close();

            Human somePerson1 = new Human();
            somePerson1.load(inputStream);
            //Human somePerson2 = new Human();
            //somePerson2.load(inputStream);
            inputStream.close();
            if (somePerson1.equals(ivanov1)) System.out.println("1 ok");
            //if (somePerson2.equals(ivanov2)) System.out.println("2 ok");
            //check here that ivanov equals to somePerson - проверьте тут, что ivanov и somePerson равны

        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Oops, something wrong with my file");
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Oops, something wrong with save/load method");
        }
    }

    public static class Human {
        public String name;
        public List<Asset> assets = new ArrayList<>();

        public Human() {
        }

        public Human(String name, Asset... assets) {
            this.name = name;
            if (assets != null) {
                this.assets.addAll(Arrays.asList(assets));
            }
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            Human human = (Human) o;

            if (name != null ? !name.equals(human.name) : human.name != null) return false;
            return assets != null ? assets.equals(human.assets) : human.assets == null;
        }

        @Override
        public int hashCode() {
            int result = name != null ? name.hashCode() : 0;
            result = 31 * result + (assets != null ? assets.hashCode() : 0);
            return result;
        }

        public void save(OutputStream outputStream) throws Exception {
            PrintWriter writer = new PrintWriter(outputStream);
            writer.println(name);
            writer.print(assets.size());
            for (int i=0;i<assets.size();i++){
                writer.print(System.lineSeparator());
                writer.println(assets.get(i).getName());
                writer.print(String.valueOf(assets.get(i).getPrice()));
            }
            writer.close();
        }

        public void load(InputStream inputStream) throws Exception {
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            name = reader.readLine();
            int size = Integer.parseInt(reader.readLine());
            for (int i=0;i<size;i++){
                Asset asset = new Asset(reader.readLine(),Double.parseDouble(reader.readLine()));
                assets.add(asset);
            }
            reader.close();
        }
    }
}
