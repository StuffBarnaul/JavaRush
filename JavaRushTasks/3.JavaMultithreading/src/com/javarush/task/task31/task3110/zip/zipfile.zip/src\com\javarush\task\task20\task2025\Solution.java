package com.javarush.task.task20.task2025;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/*
Алгоритмы-числа
*/
public class Solution {
    private static long[][] degrees = new long[10][20];
    private static int digits = 1;
    private static List<Long> list = new ArrayList<>();
    private static long currentNumber = 1;
    private static int cycles=0;

    public static long[] getNumbers(long N)
    {
        long[] armstrong = new long[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 153,
                370, 371, 407, 1634, 8208, 9474, 54748, 92727, 93084, 548834,
                1741725, 4210818, 9800817, 9926315, 24678050, 24678051, 88593477, 146511208, 472335975, 534494836,
                912985153, 4679307774L, 32164049650L, 32164049651L, 40028394225L,
                42678290603L, 44708635679L, 49388550606L, 82693916578L, 94204591914L,
                28116440335967L, 4338281769391370L, 4338281769391371L, 21897142587612075L, 35641594208964132L,
                35875699062250035L, 1517841543307505039L, 3289582984443187032L, 4498128791164624869L, 4929273885928088826L};
        ArrayList<Long> list = new ArrayList<>();
        for (int i=0;i<50;i++){
            if (armstrong[i]<N) list.add(armstrong[i]);
        }
        long [] result = new long[list.size()];
        for (int i = 0; i < list.size(); i++) {
            result[i] = list.get(i);
        }
        return result;
        /*setDegrees();
        long[] result;
        long armstrongSum;

        while(currentNumber<N) {
            armstrongSum = getArmstrongSum(currentNumber, digits);
            if (isArmstrongNumber(armstrongSum, getNumbersOfDigits(armstrongSum)))
                if (!list.contains(armstrongSum))
                    list.add(armstrongSum);
            currentNumber = getNextNumber(currentNumber);
        }
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i)>N){
                list.remove(i);
                i--;
            }
        }
        result = new long[list.size()];
        for (int i = 0; i < list.size(); i++) {
            result[i] = list.get(i);
        }
        Arrays.sort(result);
        return result;*/
    }

    private static int getNumbersOfDigits(long armstrongSum) {
        int digits = 0;
        while(armstrongSum != 0){
            armstrongSum/=10;
            digits++;
        }
        return digits;
    }

    private static long getNextNumber(long currentNumber) {
        if (currentNumber % 10 != 9){
            addZeros(currentNumber);
            currentNumber++;
            return currentNumber;
        }
        else {
            long temp = currentNumber;
            long lastFigure = 0;
            int countFigure = 0;

            addZeros(temp);
            currentNumber++;
            while (lastFigure == 0) {
                currentNumber = currentNumber / 10;
                lastFigure = currentNumber % 10;
                countFigure++;
            }

            StringBuffer sbNumber = new StringBuffer(Long.toString(currentNumber));
            for (int i = 0; i < countFigure; i++)
                sbNumber.append(lastFigure);

            if (lastFigure == 1 && countFigure == digits) digits++;
            try {
                return Long.parseLong(sbNumber.toString());
            } catch (NumberFormatException e) {
                return Long.MAX_VALUE;
            }
        }
    }

    private static void addZeros(long currentNumber) {
        if (digits<19){
            long tempSum = getArmstrongSum(currentNumber*10,digits+1);
            if (isArmstrongNumber(tempSum, getNumbersOfDigits(tempSum)))
                if (!list.contains(tempSum))
                    list.add(tempSum);
        }
        if (digits<18){
            long tempSum = getArmstrongSum(currentNumber*100,digits+2);
            if (isArmstrongNumber(tempSum, getNumbersOfDigits(tempSum)))
                if (!list.contains(tempSum))
                    list.add(tempSum);
        }
        if (digits<17){
            long tempSum = getArmstrongSum(currentNumber*1000,digits+3);
            if (isArmstrongNumber(tempSum, getNumbersOfDigits(tempSum)))
                if (!list.contains(tempSum))
                    list.add(tempSum);
        }
    }

    private static boolean isArmstrongNumber(long armstrongSum, int numberOfDegrees) {
        if (armstrongSum == getArmstrongSum(armstrongSum,numberOfDegrees))
            return true;
        else
            return false;
    }

    private static long getArmstrongSum(long currentNumber, int numberOfDegrees) {
        long sum=0;
        long temp = currentNumber;
        try{
            for (int x=0;x<numberOfDegrees;x++){
                long num = temp % 10;
                if (num<0) {    // Костыль для больших чисел
                    long t1 = temp / 1000;
                    t1*=1000;
                    t1-=temp;
                    num = t1%10;
                }
                sum+=degrees[(int) num][numberOfDegrees];
                temp/=10;
            }
            cycles++;
        } catch (IndexOutOfBoundsException e){
            System.out.println(currentNumber);
            e.printStackTrace();
        }
        return sum;
    }

    private static void setDegrees() {
        for (int x=1;x<10;x++){
            degrees[x][0] = 0;
            degrees[x][1] = x;
        }
        for (int x=0;x<10;x++){
            for (int y=2;y<degrees[x].length;y++){
                degrees[x][y] = degrees[x][y-1]*x;
            }
        }
    }

    public static void main(String args[])
    {
        Long t0 = System.currentTimeMillis();
        //Long n = 1000000000000000;
        long[] result = getNumbers(1000);
        //long[] result = getNumbers(Long.MAX_VALUE);
        Long t1 = System.currentTimeMillis();
        //System.out.println("Циклов: "+cycles+", количество итераций сократилось в "+n/cycles+" раз.");
        System.out.println(Arrays.toString(result));
        System.out.println("Time need to create the arrray = " + (t1 - t0));
        System.out.println("Used Memory in JVM: " + (Runtime.getRuntime().maxMemory() - Runtime.getRuntime().freeMemory()));
    }
}